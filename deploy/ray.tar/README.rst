Ray
===

.. image:: https://travis-ci.org/ray-project/ray.svg?branch=master
    :target: https://travis-ci.org/ray-project/ray

.. image:: https://readthedocs.org/projects/ray/badge/?version=latest
    :target: http://ray.readthedocs.io/en/latest/?badge=latest

|

Ray is a flexible, high-performance distributed execution framework.

View the `documentation`_.

.. _`documentation`: http://ray.readthedocs.io/en/latest/index.html
