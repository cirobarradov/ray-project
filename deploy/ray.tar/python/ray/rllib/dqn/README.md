Code in this package is adapted from https://github.com/openai/baselines/tree/master/baselines/deepq.
