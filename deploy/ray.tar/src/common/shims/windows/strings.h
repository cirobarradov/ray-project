#ifndef STRINGS_H
#define STRINGS_H

#endif /* STRINGS_H */
