Contact
=======

The following are good places to discuss Ray.

1. `Our Mailing List`_: For discussions about development, questions about
   usage, or any general questions.
2. `GitHub Issues`_: For bug reports and feature requests.

.. _`Our Mailing List`: https://groups.google.com/forum/#!forum/ray-dev
.. _`GitHub Issues`: https://github.com/ray-project/ray/issues
