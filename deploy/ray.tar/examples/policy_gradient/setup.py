from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from setuptools import setup, find_packages

setup(name="reinforce",
      version="0.0.1",
      packages=find_packages())
